package elasticsearch.sandbox.shell;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShellApplicationTests {

	@Test
	void contextLoads() {
	}

}
